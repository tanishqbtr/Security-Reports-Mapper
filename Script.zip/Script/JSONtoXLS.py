#import pandas
#pandas.read_json("").to_excel("")

#import tablib

#import_filename = 'C://Users/tbhatnagar/Desktop/NYL/example_1.json'
#data = open(import_filename, 'r').read()
#data_export = data.export('xlsx')
#with open('C://Users/tbhatnagar/Desktop/NYL/output1.xlsx', 'wb') as f:  # open the xlsx file
#    f.write(data_export)  # write the dataset to the xlsx file
#f.close()

import pandas as pd
df = pd.read_json (r'C://Users/tbhatnagar/Desktop/NYL/example_1.json')
df.to_csv (r'C://Users/tbhatnagar/Desktop/NYL/output1.csv', index = None)