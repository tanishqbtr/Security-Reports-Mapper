import glob
import logging
import os
import pandas as pd
import smtplib,ssl
import shutil
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.utils import formatdate
from email import encoders

CurPath = os.getcwd()

sourcelist = ('AppScan')

message = 'Summary of the current conversion:\n'

for s in sourcelist:

    l1 = (glob.glob(CurPath+"/Source/"+s+"/*.*"))
    logging.basicConfig(filename=CurPath+'/Error Logs/Error_logs.dat', level=logging.INFO,format='%(asctime)s:%(message)s')
    with open(CurPath+'/ConfigFiles/RecepientsList.dat') as f:
        toaddr = f.read().split(',')
    column_names = CurPath+'/ConfigFiles/'+s+'/ColumnNames.dat'
    column_arrangement = CurPath+'/ConfigFiles/'+s+'/ColumnArrangement.dat'
    temp_file = CurPath+'/Destination/csvfile.csv'

    message = message + "\n" + s +" : \n"
    if len(l1) == 0:
        message = message + "-> There were no files to process in the "+s+" Folder!\n"

    def ExcelToCSV(input_file):
        #change the name of file, read app name
        data_xls = pd.read_excel(input_file, skiprows = 7)
        data_xls['HCL AppScan Enterprise'].values()
        print(data_xls[][])
        output_file = CurPath + '/Destination/'+s+'/'+ input_file.split('\\')[-1].split('.')[0]+'.csv'

        if os.path.splitext(input_file)[1] == ".xlsx":
            data_xls = pd.read_excel(input_file)
            data_xls.to_csv(output_file, encoding='utf-8')

        elif os.path.splitext(input_file)[1] == ".csv":
            data = pd.read_csv(input_file)
            data.to_csv(output_file)

        else:
            raise Exception('File format is neither CSV nor XLSX.')

        # Reading column names from ConfigFile
        with open(column_names) as f:
            header_names = f.read().split(',')
        header_names = [x.strip(' ') for x in header_names]

        # Replacing column names
        file = pd.read_csv(output_file, header=None, skiprows=1, names=header_names)
        file.to_csv(temp_file)
        os.remove(output_file)

        # Rearrange column Names
        with open(column_arrangement) as f:
            reorder = f.read().split(',')

        reorder = [x.strip(' ') for x in reorder]
        df = pd.read_csv(temp_file)
        df_reorder = df[reorder]
        df_reorder.to_csv(output_file, index=False)
        os.remove(temp_file)
        os.remove(input_file)

    for ip in l1:
        try:
            ExcelToCSV(ip)
            message = message+"-> "+ip.split('\\')[-1]+' : Converted Successfully. \n'

        except Exception as error:
            logging.info('File:'+ip.split('/')[-1]+' : ' + str(error))
            message = message +"-> "+ip.split('\\')[-1] + ' : Error Encountered. '+str(error)+'\n'

# for recepient in toaddr:
#     send_mail("nyl.statuscheck@gmail.com", recepient, "Summary of the Files", message,
#         "smtp.gmail.com", 587, "nyl.statuscheck", "Tanishq@123")