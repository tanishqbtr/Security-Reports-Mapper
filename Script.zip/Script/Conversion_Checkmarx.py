import os
import pandas as pd
import xlrd
import glob
import numpy as np

CurPath = os.getcwd()

l1 = (glob.glob(CurPath+"/Source/Checkmarx"+"/*.*"))

def Convert_Files(input_file):

    data_xls = pd.read_excel(input_file, skiprows=12)
#    OutputfileName = data_xls['Application Name:'][0] + '_DAST.xls'
    output_file = CurPath + '/Destination/Checkmarx/'+ OutputfileName
    column_names = CurPath+'/ConfigFiles/Checkmarx/ColumnNames.dat'
    column_arrangement = CurPath+'/ConfigFiles/Checkmarx/ColumnArrangement.dat'
    temp_file = CurPath+'/Destination/Checkmarx/csvfile.csv'

    data_xls.to_excel(output_file)

    # Reading column names from ConfigFile
    with open(column_names) as f:
        header_names = f.read().split(',')
    header_names = [x.strip(' ') for x in header_names]

    # Replacing column names
    file = pd.read_excel(output_file, header=None, skiprows=1, names=header_names)
    file.to_csv(temp_file)
    os.remove(output_file)

    # Rearrange column Names
    with open(column_arrangement) as f:
        reorder = f.read().split(',')

    reorder = [x.strip(' ') for x in reorder]
    df = pd.read_csv(temp_file)
    df_reorder = df[reorder]
    df_reorder['Disputed Finding (Yes/No)']= np.nan
    df_reorder['Disputed Finding - Explaination'] = np.nan
    df_reorder['Remediation Plan Summary']= np.nan
    df_reorder['Remediation Completion Date Commitment'] = np.nan
    df_reorder.to_excel(output_file, index=False)
    os.remove(temp_file)
    os.remove(input_file)

for ip in l1:
    Convert_Files(ip)